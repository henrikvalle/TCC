import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import java.sql.ResultSet;

public class ConexaoBanco 
{
    Connection con;
    public boolean conecta(String local,String banco, String usuario,String senha)
    {
        boolean retorno = false;
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://" + local + "/" + banco,usuario,senha);
            retorno = true;
        }

        catch (ClassNotFoundException | SQLException e)
        {
            JOptionPane.showMessageDialog(null,e,"ERRO",JOptionPane.ERROR_MESSAGE);

        }
        return retorno;
     }
    
    public ResultSet consulta(String consulta) 
    {
        ResultSet rs = null;
        try {
                PreparedStatement stmt = (PreparedStatement)
                this.con.prepareStatement(consulta);

                rs = stmt.executeQuery();
            } catch (SQLException e) 
            {
                JOptionPane.showMessageDialog(null,e,"ERRO",JOptionPane.ERROR_MESSAGE);
            }       
        return rs;
    }
    
    
    public boolean atualiza(String comando)
    {
        boolean retorno = false;
        try 
        {
            PreparedStatement stmt = (PreparedStatement) this.con.prepareStatement(comando);

            stmt.execute();
            stmt.close();
            retorno = true;
        } 
        catch (SQLException ex) 
        {
            JOptionPane.showMessageDialog(null,ex,"ERRO",JOptionPane.ERROR_MESSAGE);
        }
        return retorno;
    }
    
   public boolean insere(String comando)
    {
        boolean retorno = false;
        try{
                PreparedStatement stmt = (PreparedStatement) this.con.prepareStatement(comando);
                stmt.execute();
                stmt.close();
                retorno = true;
            } 
        catch (SQLException ex) {
            System.err.println("Erro INSERT: " + ex);
            }
        return retorno;
    }
   
   public boolean exclui(String comando)
    {
        boolean retorno = false;
        try {
                PreparedStatement stmt = (PreparedStatement) this.con.prepareStatement(comando);
                stmt.execute();
                stmt.close();
                retorno = true;
            } catch (SQLException ex) {
                System.err.println("Erro DELETE: " + ex);
            }
        return retorno;
    }
}
